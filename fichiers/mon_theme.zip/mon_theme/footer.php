    <footer class="footer">
        © 2020 - Mon blog WordPress
    </footer>
</body>
</html>