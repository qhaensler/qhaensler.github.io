<?php get_header(); ?>

    <div class="banniere"></div>
    <div class="body">
    <main class="main">
        <div class="container">

        <?php if( have_posts() ) : while( have_posts() ) : the_post(); ?>

            <article class="article">
                <a href="article.html" class="article-img"><img src="img/article.jpg" alt=""></a>
                <div class="article-date">Publié le <?php echo get_the_date(); ?></div>
                <h2 class="article-title"><a href="article.html"><?php the_title(); ?></a></h2>
                <?php the_excerpt(); ?>
            </article>
            
        <?php endwhile; endif; ?>

        </div>
    </main>
    <aside class="sidebar">
        <h4 class="sidebar-title">Catégorie</h4>
        <ul>
            <li><a href="#">High-Tech lorem</a></li>
            <li><a href="#">Concentré du Web</a></li>
            <li><a href="#">A propos</a></li>
            <li><a href="#">Astuces pour développeurs</a></li>
            <li><a href="#">Ressources</a></li>
            <li><a href="#">Bonnes pratiques</a></li>
        </ul>
    </aside>
</div>

<?php get_footer(); ?>