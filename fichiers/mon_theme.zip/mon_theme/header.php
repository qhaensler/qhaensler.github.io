<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Mon blog WordPress</title>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style.css">
</head>
<body>
    <header class="topbar">
        <nav>
            <a href="index.html">Accueil</a>
            <a href="articles.html" class="active">Articles</a>
            <a href="apropos.html">A propos</a>
            <a href="contact.html">Contact</a>
        </nav>
        <div class="social">
            <a href="#" title="Facebook"><img src="img/facebook.png" title="Facebook"></a>
            <a href="#" title="Twitter"><img src="img/twitter.png" title="Twitter"></a>
        </div>
    </header>