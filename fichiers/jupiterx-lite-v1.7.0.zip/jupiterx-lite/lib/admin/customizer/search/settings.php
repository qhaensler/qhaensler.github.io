<?php
/**
 * Add Jupiter settings for Pages > Search > Settings tab to the WordPress Customizer.
 *
 * @package JupiterX\Framework\Admin\Customizer
 *
 * @since   1.0.0
 */

$section = 'jupiterx_search';

// Label.
JupiterX_Customizer::add_field( [
	'type'     => 'jupiterx-label',
	'settings' => 'jupiterx_search_label_1',
	'section'  => $section,
	'label'    => __( 'Display section', 'jupiterx-lite' ),
] );

// Display content.
JupiterX_Customizer::add_field( [
	'type'     => 'jupiterx-multicheck',
	'settings' => 'jupiterx_search_post_types',
	'section'  => $section,
	'default'  => [ 'post', 'portfolio', 'page', 'product' ],
	'choices'  => [
		'post'      => __( 'Post', 'jupiterx-lite' ),
		'portfolio' => __( 'Portfolio', 'jupiterx-lite' ),
		'page'      => __( 'Page', 'jupiterx-lite' ),
		'product'   => __( 'Product', 'jupiterx-lite' ),
	],
] );

// Posts per page.
JupiterX_Customizer::add_field( [
	'type'        => 'jupiterx-text',
	'settings'    => 'jupiterx_search_posts_per_page',
	'section'     => $section,
	'label'       => __( 'Posts per page', 'jupiterx-lite' ),
	'column'      => 6,
	'default'     => 5,
	'input_type'  => 'number',
	'input_attrs' => [
		'min' => 5,
	],
] );
