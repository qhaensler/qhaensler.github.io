<?php
/**
 * Add Jupiter settings for Blog Single > Settings tab to the WordPress Customizer.
 *
 * @package JupiterX\Framework\Admin\Customizer
 *
 * @since   1.0.0
 */

$section = 'jupiterx_post_single_settings';

// Template label.
JupiterX_Customizer::add_field( [
	'type'     => 'jupiterx-label',
	'settings' => 'jupiterx_post_single_label_1',
	'section'  => $section,
	'label'    => __( 'Template', 'jupiterx-lite' ),
] );

// Template.
JupiterX_Customizer::add_field( [
	'type'            => 'jupiterx-radio-image',
	'settings'        => 'jupiterx_post_single_template',
	'section'         => $section,
	'default'         => '1',
	'choices'         => [
		'1'  => 'blog-single-01',
		'2'  => [
			'name' => 'blog-single-02',
			'pro'  => true,
			'preview' => JUPITERX_ADMIN_ASSETS_URL . '/images/blog-single-2.jpg',
		],
		'3'  => [
			'name' => 'blog-single-03',
			'pro'  => true,
			'preview' => JUPITERX_ADMIN_ASSETS_URL . '/images/blog-single-3.jpg',
		],
	],
] );

// Label.
JupiterX_Customizer::add_field( [
	'type'     => 'jupiterx-label',
	'settings' => 'jupiterx_post_single_label_2',
	'section'  => $section,
	'label'    => __( 'Display Elements', 'jupiterx-lite' ),
] );

// Display elements.
JupiterX_Customizer::add_field( [
	'type'     => 'jupiterx-multicheck',
	'settings' => 'jupiterx_post_single_elements',
	'section'  => $section,
	'css_var'  => 'post-single-elements',
	'default'  => [
		'featured_image',
		'date',
		'author',
		'categories',
		'tags',
		'social_share',
		'navigation',
		'author_box',
		'related_posts',
		'comments',
	],
	'choices'  => [
		'featured_image' => __( 'Featured Image', 'jupiterx-lite' ),
		'title'          => __( 'Title', 'jupiterx-lite' ),
		'date'           => __( 'Date', 'jupiterx-lite' ),
		'author'         => __( 'Author', 'jupiterx-lite' ),
		'categories'     => __( 'Categories', 'jupiterx-lite' ),
		'tags'           => __( 'Tags', 'jupiterx-lite' ),
		'social_share'   => __( 'Social Share', 'jupiterx-lite' ),
		'navigation'     => __( 'Navigation', 'jupiterx-lite' ),
		'author_box'     => __( 'Author Box', 'jupiterx-lite' ),
		'related_posts'  => __( 'Related Posts', 'jupiterx-lite' ),
		'comments'       => __( 'Comments', 'jupiterx-lite' ),
	],
] );
