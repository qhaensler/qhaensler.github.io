<?php
/**
 * Add Jupiter settings for Portfolio Single > Settings tab to the WordPress Customizer.
 *
 * @package JupiterX\Framework\Admin\Customizer
 *
 * @since   1.0.0
 */

$section = 'jupiterx_portfolio_single_settings';

// Label.
JupiterX_Customizer::add_field( [
	'type'     => 'jupiterx-label',
	'settings' => 'jupiterx_portfolio_single_label_1',
	'section'  => $section,
	'label'    => __( 'Display Elements', 'jupiterx-lite' ),
] );

// Display elements.
JupiterX_Customizer::add_field( [
	'type'     => 'jupiterx-multicheck',
	'settings' => 'jupiterx_portfolio_single_elements',
	'section'  => $section,
	'css_var'  => 'portfolio-single-elements',
	'default'  => [
		'featured_image',
		'categories',
		'social_share',
		'navigation',
		'related_posts',
		'comments',
	],
	'choices'  => [
		'featured_image' => __( 'Featured Image', 'jupiterx-lite' ),
		'title'          => __( 'Title', 'jupiterx-lite' ),
		'date'           => __( 'Date', 'jupiterx-lite' ),
		'author'         => __( 'Author', 'jupiterx-lite' ),
		'categories'     => __( 'Categories', 'jupiterx-lite' ),
		'social_share'   => __( 'Social Share', 'jupiterx-lite' ),
		'navigation'     => __( 'Navigation', 'jupiterx-lite' ),
		'related_posts'  => __( 'Related Works', 'jupiterx-lite' ),
		'comments'       => __( 'Comments', 'jupiterx-lite' ),
	],
] );
