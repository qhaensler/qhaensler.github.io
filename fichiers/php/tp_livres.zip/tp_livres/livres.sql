-- phpMyAdmin SQL Dump
-- version 4.9.3
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:8889
-- Généré le :  mer. 25 mars 2020 à 00:45
-- Version du serveur :  5.7.26
-- Version de PHP :  7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `sdw_test`
--

-- --------------------------------------------------------

--
-- Structure de la table `livres`
--

CREATE TABLE `livres` (
  `ID` int(11) NOT NULL,
  `titre` varchar(256) NOT NULL,
  `auteur` varchar(256) NOT NULL,
  `resume` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `livres`
--

INSERT INTO `livres` (`ID`, `titre`, `auteur`, `resume`) VALUES
(1, 'La Vie secrète des écrivains', 'Guillaume Musso', 'Après avoir publié trois romans devenus cultes, le célèbre écrivain Nathan Fawles annonce qu\'il arrête d\'écrire et se retire à Beaumont, une île sauvage et sublime au large des côtes de la Méditerranée.\r\n'),
(2, 'Mourir sur Seine', 'Michel Bussi', 'Sixième jour de l’Armada 2008. Un marin est retrouvé poignardé au beau milieu des quais de Rouen ! Un meurtre… huit millions de témoins.\r\nQuel tueur invisible a pu commettre ce crime impossible ? Quel étrange pacte semble lier des matelots du monde entier ? De quels trésors enfouis dans les méandres de la Seine sont-ils à la recherche ? Quel scandale dissimulent les autorités ?\r\n'),
(3, 'Les Oubliés du dimanche', 'Valérie Perrin', 'Justine, vingt et un ans, vit chez ses grands-parents avec son cousin Jules depuis la mort de leurs parents respectifs dans un accident. Justine est aide-soignante aux Hortensias, une maison de retraite, et aime par-dessus tout les personnes âgées. Notamment Hélène, centenaire, qui a toujours rêvé d\'apprendre à lire. Les deux femmes se lient d’amitié, s\'écoutent, se révèlent l\'une à l\'autre. Grâce à la résidente, Justine va peu à peu affronter les secrets de sa propre histoire. Un jour, un mystérieux « corbeau » sème le trouble dans la maison de retraite et fait une terrible révélation.\r\n'),
(4, 'Le Bonheur n\'a pas de rides', 'Anne-Gaëlle Huon', 'Le plan de Paulette, quatre-vingt-cinq ans, semblait parfait : jouer à la vieille bique qui perd la tête et se faire payer par son fils la maison de retraite de ses rêves dans le sud de la France. Manque de chance, elle échoue dans une auberge de campagne, au milieu de nulle part.\r\n');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `livres`
--
ALTER TABLE `livres`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `livres`
--
ALTER TABLE `livres`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
