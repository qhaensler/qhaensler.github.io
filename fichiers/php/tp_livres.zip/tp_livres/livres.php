<h1>Les meilleurs livre de 2020</h1>

<p>Informations récupérées dans la base de données.</p>

<?php

    // Connexion à la base de données
    try
    {
        $bdd = new PDO('mysql:host=localhost;dbname=sdw_test;charset=utf8', 'root', 'root');
    }
    catch (Exception $e)
    {
        die('Erreur : ' . $e->getMessage());
    }

    // On fait notre requête
    $reponse = $bdd->query('SELECT * FROM livres');

    // On fait une boucle sur les résultats
    while( $donnees = $reponse->fetch() ) {
        echo '<h2>' . $donnees['titre'] . '</h2>';
        echo '<h3>' . $donnees['auteur']. '</h3>';
        echo '<p>' . $donnees['resume']. '</p>';
    }

    // On arrête l'utilisation de PDO quand la requête n'est plus utile. Ça évite les bugs
    $reponse->closeCursor();




