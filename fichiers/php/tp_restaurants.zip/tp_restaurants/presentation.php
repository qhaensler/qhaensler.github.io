<?php include('header.php'); ?>
<div class="wrapper">
    <div class="contenu">

        Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores quod provident dolore est quos, eum aut obcaecati cupiditate. Ipsum possimus voluptate quasi a illo ullam quas distinctio officiis quae eum!
        <h2>Menu du restaurant</h2>
        <ul>
            <?php

            $menu = array('Burger', 'Salade', 'Pizza');

            foreach ($menu as $plat) {
                echo '<li>' . $plat . '</li>';
            }

            ?>
        </ul>

        <h2>Liste des restaurant</h2>
        <?php

            // Connexion à la base de données
            try
            {
                $bdd = new PDO('mysql:host=localhost;dbname=sdw_test;charset=utf8', 'root', 'root');
            }
            catch (Exception $e)
            {
                die('Erreur : ' . $e->getMessage());
            }

            $reponse = $bdd->query('SELECT ville, adresse, chef FROM restaurants');
            // équivalent à $reponse = $bdd->query('SELECT * FROM restaurants');

            // Boucle
            while( $donnees = $reponse->fetch() ) {
                echo '<h3>' . $donnees['ville'] . '</h3>';
                echo '<p>Le restaurant est situé ' . $donnees['adresse'] . '</p>';
                echo '<p>Le chef est ' . $donnees['chef'] . '</p>';
            }

            // Déconnexion
            $reponse->closeCursor();

        ?>

    </div>
</div>
<?php include('footer.php'); ?>