<?php

    try
    {
        $bdd = new PDO('mysql:host=localhost;dbname=sdw_test;charset=utf8', 'root', 'root');
    }
    catch (Exception $e)
    {
        die('Erreur : ' . $e->getMessage());
    }

?>

    <form action="" method="POST">
        <input placeholder="Auteur" type="text" name="auteur">
        <br>
        <input placeholder="Titre" type="text" name="titre">
        <br>
        <textarea name="resume"></textarea>
        <br>
        <button type="submit">Ajouter le livre</button>
    </form>

<?php
    
    $reponse = $bdd->prepare('INSERT INTO livres(ID, titre, auteur, resume) VALUES (NULL, :titre, :auteur, :resume) ');
    $reponse->execute( array(
        'titre' => $_POST['titre'],
        'auteur' => $_POST['auteur'],
        'resume' => $_POST['resume']
    ) );