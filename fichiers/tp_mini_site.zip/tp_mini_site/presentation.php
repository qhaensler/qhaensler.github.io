<?php include('header.php'); ?>
<div class="wrapper">
    <div class="contenu">

        Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores quod provident dolore est quos, eum aut obcaecati cupiditate. Ipsum possimus voluptate quasi a illo ullam quas distinctio officiis quae eum!
        <h2>Menu du restaurant</h2>
        <ul>
            <?php

            $menu = array('Burger', 'Salade', 'Pizza');

            foreach ($menu as $plat) {
                echo '<li>' . $plat . '</li>';
            }

            ?>
        </ul>

        <h2>Liste des restaurant</h2>
        <?php

        $restaurants = array(
            [
                'ville' => 'Strasbourg',
                'adresse' => 'Rue du Bassin d\'Austerlitz',
                'chef' => 'Pierre'
            ],
            [
                'ville' => 'Haguenau',
                'adresse' => 'Grand Rue',
                'chef' => 'Camille'
            ],
            [
                'ville' => 'Colmar',
                'adresse' => 'Grand Rue',
                'chef' => 'Lucas'
            ],
        );

        foreach ($restaurants as $resto) {
            echo '<h3>' . $resto['ville'] . '</h3>';
            echo '<p>Le restaurant est situé ' . $resto['adresse'] . '</p>';
            echo '<p>Le chef est ' . $resto['chef'] . '</p>';
        }

        ?>

    </div>
</div>
<?php include('footer.php'); ?>