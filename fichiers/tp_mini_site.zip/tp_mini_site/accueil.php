<?php include('header.php'); ?>
<div class="wrapper">
    <div class="contenu">

        <p>
            <b>
                <?php

                $ouvert = false;

                if ($ouvert == true) {
                    echo 'Le restaurant est ouvert !';
                } else {
                    echo 'Le restaurant est fermé !';
                }

                ?>
            </b>
        </p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magnam blanditiis unde provident, fuga distinctio officiis repudiandae maxime minus facere. Provident reiciendis repudiandae atque doloremque mollitia. Voluptas ducimus quae rerum id?
    </div>
</div>
<?php include('footer.php'); ?>