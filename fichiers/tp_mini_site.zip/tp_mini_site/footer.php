    <div class="footer">
        2020 - Mon super site
    </div>
</body>

</html>