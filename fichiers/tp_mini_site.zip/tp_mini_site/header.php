<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">

</head>
<body>
    <div class="header">
        <div class="wrapper">
            <h1>Mon restaurant</h1>
            <ul class="menu">
                <li><a href="accueil.php">Accueil</a></li>
                <li><a href="presentation.php">Présentation</a></li>
                <li>Contact</li>
            </ul>
        </div>
    </div>